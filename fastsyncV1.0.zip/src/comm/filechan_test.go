package comm

import (
	"fmt"
	"testing"
)

func TestFilechan(t *testing.T) {
	LeveldbDB.Open()
	f := NewFileChan("E:/TEST/test2", "*.txt")
	f.Start()
	for {
		select {
		case l := <-f.LineChan:
			fmt.Println(l)
		}
	}

}
